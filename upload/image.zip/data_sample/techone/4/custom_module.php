<?php 
$language_id = 2;
foreach($data['languages'] as $language) {
   if($language['language_id'] != 1) {
       $language_id = $language['language_id'];
   }
}
                 
$output = array();
$output["custom_module_module"] = array (
  1 => 
  array (
    'type' => '2',
    'block_heading' => 
    array (
      $language_id => '',
      1 => '',
    ),
    'block_content' => 
    array (
      $language_id => '',
      1 => '',
    ),
    'html' => 
    array (
      $language_id => '<div class="header-socilas">
<a class="social" target="_blank" href="https://twitter.com" title="Twitter"><i class="fa fa-twitter"></i></a>                                <a class="social" target="_blank" href="https://facebook.com" title="Facebook"><i class="fa fa-facebook"></i></a>                                <a class="social" target="_blank" href="" title="Google plus"><i class="fa fa-google-plus" aria-hidden="true"></i></a>                                <a class="social" target="_blank" href="" title="Dribbble"><i class="fa fa-dribbble" aria-hidden="true"></i></a>                                <a class="social" target="_blank" href="" title="Behance"><i class="fa fa-behance" aria-hidden="true"></i></a>                            </div>',
      1 => '<div class="header-socilas">
<a class="social" target="_blank" href="https://twitter.com" title="Twitter"><i class="fa fa-twitter"></i></a>                                <a class="social" target="_blank" href="https://facebook.com" title="Facebook"><i class="fa fa-facebook"></i></a>                                <a class="social" target="_blank" href="" title="Google plus"><i class="fa fa-google-plus" aria-hidden="true"></i></a>                                <a class="social" target="_blank" href="" title="Dribbble"><i class="fa fa-dribbble" aria-hidden="true"></i></a>                                <a class="social" target="_blank" href="" title="Behance"><i class="fa fa-behance" aria-hidden="true"></i></a>                            </div>',
    ),
    'layout_id' => '99999',
    'position' => 'top_block',
    'status' => '1',
    'sort_order' => '',
  ),
  2 => 
  array (
    'type' => '2',
    'block_heading' => 
    array (
      $language_id => '',
      1 => '',
    ),
    'block_content' => 
    array (
      $language_id => '',
      1 => '',
    ),
    'html' => 
    array (
      $language_id => '<div class="hotline">
<span class="icon"><i class="fa fa-phone" aria-hidden="true"></i></span>
<span class="content">
<span class="text">Call us now</span>
<span class="phone">(080)123 4567 891</span>
</span>
</div>',
      1 => '<div class="hotline">
<span class="icon"><i class="fa fa-phone" aria-hidden="true"></i></span>
<span class="content">
<span class="text">Call us now</span>
<span class="phone">(080)123 4567 891</span>
</span>
</div>',
    ),
    'layout_id' => '99999',
    'position' => 'top_block',
    'status' => '1',
    'sort_order' => '',
  ),
  3 => 
  array (
    'type' => '2',
    'block_heading' => 
    array (
      $language_id => '',
      1 => '',
    ),
    'block_content' => 
    array (
      $language_id => '',
      1 => '',
    ),
    'html' => 
    array (
      $language_id => '<div class="row banners">
	<div class="col-sm-6"><a href="#"><img src="image/catalog/version4/banner_01.jpg" alt=""></a></div>
	<div class="col-sm-6"><a href="#"><img src="image/catalog/version4/banner_02.jpg" alt=""></a></div>
</div>',
      1 => '<div class="row banners">
	<div class="col-sm-6"><a href="#"><img src="image/catalog/version4/banner_01.jpg" alt=""></a></div>
	<div class="col-sm-6"><a href="#"><img src="image/catalog/version4/banner_02.jpg" alt=""></a></div>
</div>',
    ),
    'layout_id' => '1',
    'position' => 'content_top',
    'status' => '1',
    'sort_order' => '2',
  ),
  4 => 
  array (
    'type' => '2',
    'block_heading' => 
    array (
      $language_id => '',
      1 => '',
    ),
    'block_content' => 
    array (
      $language_id => '',
      1 => '',
    ),
    'html' => 
    array (
      $language_id => '<div class="row banners">
	<div class="col-sm-12"><a href="#"><img src="image/catalog/shop_banner.jpg" alt=""></a></div>
</div>',
      1 => '<div class="row banners">
	<div class="col-sm-12"><a href="#"><img src="image/catalog/shop_banner.jpg" alt=""></a></div>
</div>',
    ),
    'layout_id' => '3',
    'position' => 'column_left',
    'status' => '1',
    'sort_order' => '4',
  ),
  5 => 
  array (
    'type' => '2',
    'block_heading' => 
    array (
      $language_id => '',
      1 => '',
    ),
    'block_content' => 
    array (
      $language_id => '',
      1 => '',
    ),
    'html' => 
    array (
      $language_id => '<div style="background: #f5f5f5">
	<div class="container" style="padding-left: 0 !important;padding-right: 0 !important">
		<div id="carousel2" class="owl-carousel carousel-brands" style="margin: 0px !important;padding: 0px !important">
			<div class="item text-center">
				<img src="image/cache/catalog/brand1-210x112.jpg" alt="Starbucks" class="img-responsive" />
			</div>
			
			<div class="item text-center">
				<img src="image/cache/catalog/brand1-210x112.jpg" alt="Nintendo" class="img-responsive" />
			</div>
			
			<div class="item text-center">
				<img src="image/cache/catalog/brand1-210x112.jpg" alt="NFL" class="img-responsive" />
			</div>
			
			<div class="item text-center">
				<img src="image/cache/catalog/brand1-210x112.jpg" alt="RedBull" class="img-responsive" />
			</div>
			
			<div class="item text-center">
				<img src="image/cache/catalog/brand1-210x112.jpg" alt="Coca Cola" class="img-responsive" />
			</div>
			
			<div class="item text-center">
				<img src="image/cache/catalog/brand1-210x112.jpg" alt="Sony" class="img-responsive" />
			</div>
			
			<div class="item text-center">
				<img src="image/cache/catalog/brand1-210x112.jpg" alt="Burger King" class="img-responsive" />
			</div>
			
			<div class="item text-center">
				<img src="image/cache/catalog/brand1-210x112.jpg" alt="Canon" class="img-responsive" />
			</div>
			
			<div class="item text-center">
				<img src="image/cache/catalog/brand1-210x112.jpg" alt="Harley Davidson" class="img-responsive" />
			</div>
			
			<div class="item text-center">
				<img src="image/cache/catalog/brand1-210x112.jpg" alt="Dell" class="img-responsive" />
			</div>
			
			<div class="item text-center">
				<img src="image/cache/catalog/brand1-210x112.jpg" alt="Disney" class="img-responsive" />
			</div>
		</div>
	</div>
</div>

<script type="text/javascript"><!--
$(\'#carousel2\').owlCarousel({
	items: 5,
	autoPlay: 3000,
	navigation: true,
	navigationText: false,
	pagination: true
});
--></script>',
      1 => '<div style="background: #f5f5f5">
	<div class="container" style="padding-left: 0 !important;padding-right: 0 !important">
		<div id="carousel2" class="owl-carousel carousel-brands" style="margin: 0px !important;padding: 0px !important">
			<div class="item text-center">
				<img src="image/cache/catalog/brand1-210x112.jpg" alt="Starbucks" class="img-responsive" />
			</div>
			
			<div class="item text-center">
				<img src="image/cache/catalog/brand1-210x112.jpg" alt="Nintendo" class="img-responsive" />
			</div>
			
			<div class="item text-center">
				<img src="image/cache/catalog/brand1-210x112.jpg" alt="NFL" class="img-responsive" />
			</div>
			
			<div class="item text-center">
				<img src="image/cache/catalog/brand1-210x112.jpg" alt="RedBull" class="img-responsive" />
			</div>
			
			<div class="item text-center">
				<img src="image/cache/catalog/brand1-210x112.jpg" alt="Coca Cola" class="img-responsive" />
			</div>
			
			<div class="item text-center">
				<img src="image/cache/catalog/brand1-210x112.jpg" alt="Sony" class="img-responsive" />
			</div>
			
			<div class="item text-center">
				<img src="image/cache/catalog/brand1-210x112.jpg" alt="Burger King" class="img-responsive" />
			</div>
			
			<div class="item text-center">
				<img src="image/cache/catalog/brand1-210x112.jpg" alt="Canon" class="img-responsive" />
			</div>
			
			<div class="item text-center">
				<img src="image/cache/catalog/brand1-210x112.jpg" alt="Harley Davidson" class="img-responsive" />
			</div>
			
			<div class="item text-center">
				<img src="image/cache/catalog/brand1-210x112.jpg" alt="Dell" class="img-responsive" />
			</div>
			
			<div class="item text-center">
				<img src="image/cache/catalog/brand1-210x112.jpg" alt="Disney" class="img-responsive" />
			</div>
		</div>
	</div>
</div>

<script type="text/javascript"><!--
$(\'#carousel2\').owlCarousel({
	items: 5,
	autoPlay: 3000,
	navigation: true,
	navigationText: false,
	pagination: true
});
--></script>',
    ),
    'layout_id' => '1',
    'position' => 'customfooter_top',
    'status' => '1',
    'sort_order' => '',
  ),
  6 => 
  array (
    'type' => '2',
    'block_heading' => 
    array (
      $language_id => '',
      1 => '',
    ),
    'block_content' => 
    array (
      $language_id => '',
      1 => '',
    ),
    'html' => 
    array (
      $language_id => '<div class="row banners">
	<div class="col-sm-12"><a href="#"><img src="image/catalog/version3/banner_03.jpg" alt=""></a></div>
</div>',
      1 => '<div class="row banners">
	<div class="col-sm-12"><a href="#"><img src="image/catalog/version3/banner_03.jpg" alt=""></a></div>
</div>',
    ),
    'layout_id' => '1',
    'position' => 'content_top',
    'status' => '1',
    'sort_order' => '5',
  ),
  7 => 
  array (
    'type' => '2',
    'block_heading' => 
    array (
      $language_id => '',
      1 => '',
    ),
    'block_content' => 
    array (
      $language_id => '',
      1 => '',
    ),
    'html' => 
    array (
      $language_id => '<div class="margin-left-34">
  <div class="row banners">
	<div class="col-sm-12" style="padding-top: 8px"><a href="#"><img src="image/catalog/version4/pro-code.jpg" alt=""></a></div>
  </div>
</div>',
      1 => '<div class="margin-left-34">
  <div class="row banners">
	<div class="col-sm-12" style="padding-top: 8px"><a href="#"><img src="image/catalog/version4/pro-code.jpg" alt=""></a></div>
  </div>
</div>',
    ),
    'layout_id' => '1',
    'position' => 'content_top',
    'status' => '1',
    'sort_order' => '1',
  ),
  8 => 
  array (
    'type' => '2',
    'block_heading' => 
    array (
      $language_id => '',
      1 => '',
    ),
    'block_content' => 
    array (
      $language_id => '',
      1 => '',
    ),
    'html' => 
    array (
      $language_id => '<div class="row banners">
	<div class="col-sm-12"><a href="#"><img src="image/catalog/version4/banner_03.jpg" alt=""></a></div>
</div>',
      1 => '<div class="row banners">
	<div class="col-sm-12"><a href="#"><img src="image/catalog/version4/banner_03.jpg" alt=""></a></div>
</div>',
    ),
    'layout_id' => '1',
    'position' => 'column_right',
    'status' => '1',
    'sort_order' => '2',
  ),
  9 => 
  array (
    'type' => '2',
    'block_heading' => 
    array (
      $language_id => '',
      1 => '',
    ),
    'block_content' => 
    array (
      $language_id => '',
      1 => '',
    ),
    'html' => 
    array (
      $language_id => '<div class="box">
	<div class="box-heading">Testimonials</div>
	<a class="next" href="#Testimonials" id="Testimonials_next"><span></span></a>
	<a class="prev" href="#Testimonials" id="Testimonials_prev"><span></span></a>
	
	<div class="box-content">
		<div class="owl-carousel" id="Testimonials">
			<div class="item">
				<div class="testimonial-item">
					<div class="heade-info">
						<div class="avatar">
							<img alt="" class="img-responsive" src="image/catalog/version4/avatar1.jpg" width="70" height="70">
						</div>
					</div>
					
					<div class="testimonial-info">
						<p>Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat.</p>
					</div>
				</div>
			</div>
			
			<div class="item">
				<div class="testimonial-item">
					<div class="heade-info">
						<div class="avatar">
							<img alt="" class="img-responsive" src="image/catalog/version4/avatar2.jpg" width="70" height="70">
						</div>
					</div>
					
					<div class="testimonial-info">
						<p>Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolor</p>
					</div>
				</div>
			</div>
			
			<div class="item">
				<div class="testimonial-item">
					<div class="heade-info">
						<div class="avatar">
							<img alt="" class="img-responsive" src="image/catalog/version4/avatar3.jpg" width="70" height="70">
						</div>
					</div>
					
					<div class="testimonial-info">
						<p>Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolor</p>
					</div>
				</div>
			</div>
		</div>
	</div>
</div>

<script type="text/javascript">
$(document).ready(function() {
	var Testimonials = $(".box #Testimonials");
		
	$("#Testimonials_next").click(function(){
	    Testimonials.trigger(\'owl.next\');
	    return false;
	  })
	$("#Testimonials_prev").click(function(){
	    Testimonials.trigger(\'owl.prev\');
	    return false;
	});
	  
	Testimonials.owlCarousel({
		autoPlay: 6000, //Set AutoPlay to 3 seconds
		navigation: false,
		singleItem: true
	 });
});
</script>	',
      1 => '<div class="box">
	<div class="box-heading">Testimonials</div>
	<a class="next" href="#Testimonials" id="Testimonials_next"><span></span></a>
	<a class="prev" href="#Testimonials" id="Testimonials_prev"><span></span></a>
	
	<div class="box-content">
		<div class="owl-carousel" id="Testimonials">
			<div class="item">
				<div class="testimonial-item">
					<div class="heade-info">
						<div class="avatar">
							<img alt="" class="img-responsive" src="image/catalog/version4/avatar1.jpg" width="70" height="70">
						</div>
					</div>
					
					<div class="testimonial-info">
						<p>Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat.</p>
					</div>
				</div>
			</div>
			
			<div class="item">
				<div class="testimonial-item">
					<div class="heade-info">
						<div class="avatar">
							<img alt="" class="img-responsive" src="image/catalog/version4/avatar2.jpg" width="70" height="70">
						</div>
					</div>
					
					<div class="testimonial-info">
						<p>Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolor</p>
					</div>
				</div>
			</div>
			
			<div class="item">
				<div class="testimonial-item">
					<div class="heade-info">
						<div class="avatar">
							<img alt="" class="img-responsive" src="image/catalog/version4/avatar3.jpg" width="70" height="70">
						</div>
					</div>
					
					<div class="testimonial-info">
						<p>Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolor</p>
					</div>
				</div>
			</div>
		</div>
	</div>
</div>

<script type="text/javascript">
$(document).ready(function() {
	var Testimonials = $(".box #Testimonials");
		
	$("#Testimonials_next").click(function(){
	    Testimonials.trigger(\'owl.next\');
	    return false;
	  })
	$("#Testimonials_prev").click(function(){
	    Testimonials.trigger(\'owl.prev\');
	    return false;
	});
	  
	Testimonials.owlCarousel({
		autoPlay: 6000, //Set AutoPlay to 3 seconds
		navigation: false,
		singleItem: true
	 });
});
</script>	',
    ),
    'layout_id' => '1',
    'position' => 'column_right',
    'status' => '1',
    'sort_order' => '5',
  ),
); 

$this->model_setting_setting->editSetting( "custom_module", $output );	

?>
<?php 

_e(ControllerExtensionModulerevslideropencart::$lang_var['general_settings'],"revslider");

_e(ControllerExtensionModulerevslideropencart::$lang_var['Position'],"revslider"); 

_e(ControllerExtensionModulerevslideropencart::$lang_var['Appearance'],"revslider");

_e(ControllerExtensionModulerevslideropencart::$lang_var['Navigation'],"revslider"); 

_e(ControllerExtensionModulerevslideropencart::$lang_var['Thumbnails'],"revslider"); 

_e(ControllerExtensionModulerevslideropencart::$lang_var['Mobile_Visibility'],"revslider");
_e(ControllerExtensionModulerevslideropencart::$lang_var['Alternative_First'],"revslider");
_e(ControllerExtensionModulerevslideropencart::$lang_var['Troubleshooting'],"revslider"); 

_e(ControllerExtensionModulerevslideropencart::$lang_var['Delay'],"revslider"); 

_e(ControllerExtensionModulerevslideropencart::$lang_var['slide_stays'],"revslider"); 

_e(ControllerExtensionModulerevslideropencart::$lang_var['Shuffle_Mode'],"revslider"); 

_e(ControllerExtensionModulerevslideropencart::$lang_var['Turn_Shuffle'],"revslider"); 

_e(ControllerExtensionModulerevslideropencart::$lang_var['Lazy_Load'],"revslider"); 

_e(ControllerExtensionModulerevslideropencart::$lang_var['lazy_load_desc'],"revslider"); 

_e(ControllerExtensionModulerevslideropencart::$lang_var['Load_Google_Font'],"revslider");

_e(ControllerExtensionModulerevslideropencart::$lang_var['yes_Google_Font'],"revslider"); 

_e(ControllerExtensionModulerevslideropencart::$lang_var['Google_Font'],"revslider"); 

_e(ControllerExtensionModulerevslideropencart::$lang_var['google_font_family'],"revslider"); 

_e(ControllerExtensionModulerevslideropencart::$lang_var['more_google'],"revslider"); 

_e(ControllerExtensionModulerevslideropencart::$lang_var['Stop_Slider'],"revslider"); 

_e(ControllerExtensionModulerevslideropencart::$lang_var['On_Off_loops'],"revslider"); 

_e(ControllerExtensionModulerevslideropencart::$lang_var['Stop_After_Loops'],"revslider");

_e(ControllerExtensionModulerevslideropencart::$lang_var['certain_amount_loops'],"revslider");

_e(ControllerExtensionModulerevslideropencart::$lang_var['Stop_At_Slide'],"revslider"); 

_e(ControllerExtensionModulerevslideropencart::$lang_var['given_slide'],"revslider"); 

_e(ControllerExtensionModulerevslideropencart::$lang_var['Position_page'],"revslider"); 

_e(ControllerExtensionModulerevslideropencart::$lang_var['Position_slider'],"revslider"); 

_e(ControllerExtensionModulerevslideropencart::$lang_var['Left'],"revslider"); 

_e(ControllerExtensionModulerevslideropencart::$lang_var['Center'],"revslider"); 

_e(ControllerExtensionModulerevslideropencart::$lang_var['Right'],"revslider"); 

_e(ControllerExtensionModulerevslideropencart::$lang_var['Margin_Top'],"revslider"); 

_e(ControllerExtensionModulerevslideropencart::$lang_var['top_wrapper'],"revslider"); 

_e(ControllerExtensionModulerevslideropencart::$lang_var['px'],"revslider"); 

_e(ControllerExtensionModulerevslideropencart::$lang_var['Margin_Bottom'],"revslider"); 

_e(ControllerExtensionModulerevslideropencart::$lang_var['bottom_wrapper'],"revslider");

_e(ControllerExtensionModulerevslideropencart::$lang_var['Margin_left'],"revslider"); 

_e(ControllerExtensionModulerevslideropencart::$lang_var['left_margin_wrapper'],"revslider");

_e(ControllerExtensionModulerevslideropencart::$lang_var['Margin_wrapper_div'],"revslider"); 

_e(ControllerExtensionModulerevslideropencart::$lang_var['right_wrapper'],"revslider"); 

_e(ControllerExtensionModulerevslideropencart::$lang_var['Shadow_Type'],"revslider"); 

_e(ControllerExtensionModulerevslideropencart::$lang_var['slider_shadow'],"revslider"); 

_e(ControllerExtensionModulerevslideropencart::$lang_var['No_Shadow'],"revslider"); 

_e(ControllerExtensionModulerevslideropencart::$lang_var['1'],"revslider"); 

_e(ControllerExtensionModulerevslideropencart::$lang_var['2'],"revslider"); 

_e(ControllerExtensionModulerevslideropencart::$lang_var['3'],"revslider"); 

_e(ControllerExtensionModulerevslideropencart::$lang_var['Show_Timer_Show'],"revslider");

_e(ControllerExtensionModulerevslideropencart::$lang_var['running_timer_line'],"revslider");

_e(ControllerExtensionModulerevslideropencart::$lang_var['Top'],"revslider");

_e(ControllerExtensionModulerevslideropencart::$lang_var['Bottom'],"revslider"); 

_e(ControllerExtensionModulerevslideropencart::$lang_var['Hide'],"revslider"); 

_e(ControllerExtensionModulerevslideropencart::$lang_var['Background_color'],"revslider");

_e(ControllerExtensionModulerevslideropencart::$lang_var['transparent_slider'],"revslider");

_e(ControllerExtensionModulerevslideropencart::$lang_var['Padding_border'],"revslider"); 

_e(ControllerExtensionModulerevslideropencart::$lang_var['border_around_slider'],"revslider");

_e(ControllerExtensionModulerevslideropencart::$lang_var['Show_Background_Image'],"revslider");

_e(ControllerExtensionModulerevslideropencart::$lang_var['main_slider_wrapper'],"revslider"); 

_e(ControllerExtensionModulerevslideropencart::$lang_var['Background_Image_Url'],"revslider"); 

_e(ControllerExtensionModulerevslideropencart::$lang_var['slider_preloading'],"revslider"); 

_e(ControllerExtensionModulerevslideropencart::$lang_var['Touch_Enabled'],"revslider"); 

_e(ControllerExtensionModulerevslideropencart::$lang_var['Function_touch_devices'],"revslider");

_e(ControllerExtensionModulerevslideropencart::$lang_var['Stop_On_Hover'],"revslider"); 

_e(ControllerExtensionModulerevslideropencart::$lang_var['hovering_Navigation'],"revslider");

_e(ControllerExtensionModulerevslideropencart::$lang_var['Navigation_Type'],"revslider");

_e(ControllerExtensionModulerevslideropencart::$lang_var['navigation_bar'],"revslider"); 

_e(ControllerExtensionModulerevslideropencart::$lang_var['None'],"revslider"); 

_e(ControllerExtensionModulerevslideropencart::$lang_var['Bullet'],"revslider"); 

_e(ControllerExtensionModulerevslideropencart::$lang_var['Thumb'],"revslider"); 

_e(ControllerExtensionModulerevslideropencart::$lang_var['Both'],"revslider"); 

_e(ControllerExtensionModulerevslideropencart::$lang_var['Navigation_Arrows'],"revslider");

_e(ControllerExtensionModulerevslideropencart::$lang_var['navigation_Thumb_arrows'],"revslider"); 

_e(ControllerExtensionModulerevslideropencart::$lang_var['With_Bullets'],"revslider"); 

_e(ControllerExtensionModulerevslideropencart::$lang_var['Solo'],"revslider"); 

_e(ControllerExtensionModulerevslideropencart::$lang_var['Navigation_Style'],"revslider");

_e(ControllerExtensionModulerevslideropencart::$lang_var['Navigation_nexttobullets'],"revslider");

_e(ControllerExtensionModulerevslideropencart::$lang_var['Round'],"revslider"); 

_e(ControllerExtensionModulerevslideropencart::$lang_var['Navbar'],"revslider"); 

_e(ControllerExtensionModulerevslideropencart::$lang_var['Old_Round'],"revslider");

_e(ControllerExtensionModulerevslideropencart::$lang_var['Old_Square'],"revslider");

_e(ControllerExtensionModulerevslideropencart::$lang_var['Old_Navbar'],"revslider"); 

_e(ControllerExtensionModulerevslideropencart::$lang_var['Always_Show_Navigation'],"revslider"); 

_e(ControllerExtensionModulerevslideropencart::$lang_var['show_navigation_thumbnails'],"revslider"); 

_e(ControllerExtensionModulerevslideropencart::$lang_var['Hide_Navitagion_After'],"revslider"); 

_e(ControllerExtensionModulerevslideropencart::$lang_var['Time_Navigatio_hidden'],"revslider"); 

_e(ControllerExtensionModulerevslideropencart::$lang_var['ms'],"revslider"); 

_e(ControllerExtensionModulerevslideropencart::$lang_var['Navigation_Horizontal_Align'],"revslider");

_e(ControllerExtensionModulerevslideropencart::$lang_var['Horizontal_Align_Bullets'],"revslider");

_e(ControllerExtensionModulerevslideropencart::$lang_var['Navigation_Vertical_Align'],"revslider");

_e(ControllerExtensionModulerevslideropencart::$lang_var['Vertical_Align_Bullets'],"revslider");

_e(ControllerExtensionModulerevslideropencart::$lang_var['Navigation_Horizontal_Offset'],"revslider");

_e(ControllerExtensionModulerevslideropencart::$lang_var['Horizontal_position_Bullets'],"revslider"); 

_e(ControllerExtensionModulerevslideropencart::$lang_var['Navigation_Vertical_Offset'],"revslider"); 

_e(ControllerExtensionModulerevslideropencart::$lang_var['current_Vertical_position'],"revslider");

_e(ControllerExtensionModulerevslideropencart::$lang_var['Left_Arrow_Horizontal'],"revslider"); 

_e(ControllerExtensionModulerevslideropencart::$lang_var['Horizontal_Align_left'],"revslider"); 

_e(ControllerExtensionModulerevslideropencart::$lang_var['Left_Arrow_Vertical'],"revslider"); 

_e(ControllerExtensionModulerevslideropencart::$lang_var['Vertical_Align_left'],"revslider"); 

_e(ControllerExtensionModulerevslideropencart::$lang_var['Left_Arrow_Offset'],"revslider"); 

_e(ControllerExtensionModulerevslideropencart::$lang_var['Offset_Horizontal_position'],"revslider"); 

_e(ControllerExtensionModulerevslideropencart::$lang_var['Vertical_Offset'],"revslider"); 

_e(ControllerExtensionModulerevslideropencart::$lang_var['Offset_Vertical_position'],"revslider");

_e(ControllerExtensionModulerevslideropencart::$lang_var['Right_Arrow_Horizontal'],"revslider"); 

_e(ControllerExtensionModulerevslideropencart::$lang_var['Horizontal_Align'],"revslider"); 

_e(ControllerExtensionModulerevslideropencart::$lang_var['Right_Arrow_Align'],"revslider"); 

_e(ControllerExtensionModulerevslideropencart::$lang_var['Vertical_right_Arrow'],"revslider"); 

_e(ControllerExtensionModulerevslideropencart::$lang_var['Right_Horizontal'],"revslider"); 

_e(ControllerExtensionModulerevslideropencart::$lang_var['current_Horizontal_position'],"revslider"); 

_e(ControllerExtensionModulerevslideropencart::$lang_var['Right_Offset'],"revslider"); 

_e(ControllerExtensionModulerevslideropencart::$lang_var['position_negative_direction'],"revslider"); 

_e(ControllerExtensionModulerevslideropencart::$lang_var['Thumb_Width'],"revslider"); 

_e(ControllerExtensionModulerevslideropencart::$lang_var['thumb_selected'],"revslider"); 

_e(ControllerExtensionModulerevslideropencart::$lang_var['Thumb_Height'],"revslider"); 

_e(ControllerExtensionModulerevslideropencart::$lang_var['Thumbnail_selected'],"revslider");

_e(ControllerExtensionModulerevslideropencart::$lang_var['Thumb_Amount'],"revslider"); 

_e(ControllerExtensionModulerevslideropencart::$lang_var['Thumbs_visible_selected'],"revslider");

_e(ControllerExtensionModulerevslideropencart::$lang_var['Hide_Under_Width'],"revslider");

_e(ControllerExtensionModulerevslideropencart::$lang_var['Hide_slider_width'],"revslider");

_e(ControllerExtensionModulerevslideropencart::$lang_var['Hide_Layers_Under'],"revslider");

_e(ControllerExtensionModulerevslideropencart::$lang_var['Hide_layer_properties'],"revslider");

_e(ControllerExtensionModulerevslideropencart::$lang_var['Hide_Layers_Under'],"revslider"); 

_e(ControllerExtensionModulerevslideropencart::$lang_var['layers_some_width'],"revslider"); 

_e(ControllerExtensionModulerevslideropencart::$lang_var['Start_With_Slide'],"revslider"); 

_e(ControllerExtensionModulerevslideropencart::$lang_var['Change_want_start'],"revslider"); 

_e(ControllerExtensionModulerevslideropencart::$lang_var['First_Transition_Active'],"revslider"); 

_e(ControllerExtensionModulerevslideropencart::$lang_var['overwrite_first_slide'],"revslider");

_e(ControllerExtensionModulerevslideropencart::$lang_var['First_Transition_Type'],"revslider");

_e(ControllerExtensionModulerevslideropencart::$lang_var['First_slide_transition'],"revslider");

_e(ControllerExtensionModulerevslideropencart::$lang_var['Replace_me'],"revslider"); 

_e(ControllerExtensionModulerevslideropencart::$lang_var['First_Transition_Duration'],"revslider");

_e(ControllerExtensionModulerevslideropencart::$lang_var['First_slide_duration'],"revslider"); 

_e(ControllerExtensionModulerevslideropencart::$lang_var['First_Transition_Slot'],"revslider");

_e(ControllerExtensionModulerevslideropencart::$lang_var['slide_divided'],"revslider"); 

_e(ControllerExtensionModulerevslideropencart::$lang_var['JQuery_No_Conflict'],"revslider"); 

_e(ControllerExtensionModulerevslideropencart::$lang_var['jquery_mode'],"revslider"); 

_e(ControllerExtensionModulerevslideropencart::$lang_var['JS_Includes_Body'],"revslider"); 

_e(ControllerExtensionModulerevslideropencart::$lang_var['Putting_javascript_conflicts'],"revslider"); 

_e(ControllerExtensionModulerevslideropencart::$lang_var['True'],"revslider"); 

_e(ControllerExtensionModulerevslideropencart::$lang_var['False'],"revslider"); 

_e(ControllerExtensionModulerevslideropencart::$lang_var['Output_Filters_Protection'],"revslider"); 

_e(ControllerExtensionModulerevslideropencart::$lang_var['protection_against_wordpress'],"revslider"); 

_e(ControllerExtensionModulerevslideropencart::$lang_var['Compressing_Output'],"revslider"); 

_e(ControllerExtensionModulerevslideropencart::$lang_var['Echo_Output'],"revslider");  

?>
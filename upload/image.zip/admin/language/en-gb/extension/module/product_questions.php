<?php

// Heading Goes here:
$_['heading_title']    = '<b>Product Questions</b>';

// Text
$_['text_success']     = 'Success: You have modified module Product Questions!';

// Error
$_['error_permission'] = 'Warning: You do not have permission to modify module Product Questions!';

?>
